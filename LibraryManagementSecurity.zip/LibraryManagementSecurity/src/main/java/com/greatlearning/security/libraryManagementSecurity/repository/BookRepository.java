package com.greatlearning.security.libraryManagementSecurity.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.greatlearning.security.libraryManagementSecurity.entity.Book;

public interface BookRepository extends JpaRepository <Book,Integer> {

	List <Book> findByNameContainsAndAuthorContainsAllIgnoreCase(String name,String author);
}
