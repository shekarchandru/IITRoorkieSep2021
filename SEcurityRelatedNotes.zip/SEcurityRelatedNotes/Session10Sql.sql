create database studentsdb;
use studentsdb;

create table student
(
id int primary key auto_increment,
fname varchar(50),
lname varchar(50),
course varchar(50),
country varchar(50)
);
insert into student(fname,lname,course,country)
values('Suraj','Bhatia','M.Tech','India');

select * from student;

use booksdb;
select * from book;

create table users
(
user_id int primary key auto_increment,
password varchar(200),
username varchar(200)
);
# user1 123456 $2a$12$fPG46xw31I6NnJfgR.UPjOAB5ZXk9Riq5/fF7mIiCek8iV.hMIApu
# user2 1234 $2a$12$N3tpuXet7YlYK2Xe2bWayux4/SimjLPA964wCWro2mduLVcHE9TOq

select * from users;
select * from roles;
select * from user_roles; 
insert into users(user_id,username)
values(1,'user1');

insert into users(user_id,username)
values(2,'user2');
select * from roles;
create table roles
(
role_id int primary key auto_increment,
name varchar(50)
);
insert into roles
values(1,'ADMIN');
insert into roles
values(2,'USER');
/*
create table user_roles
(
user_id int,
role_id int,
foreign key(user_id) references users(user_id),
foreign key(role_id) references roles(role_id) 
);*/
create table user_roles
(
user_id int,
role_id int,
foreign key(user_id) references users(user_id),
foreign key(role_id) references roles(role_id)
);
drop table user_roles;
insert into user_roles
values(1,1);
insert into user_roles
values(2,2);

select * from roles;
select * from user;
select * from user_roles;
drop table user;
drop table roles;
drop table user_roles;




