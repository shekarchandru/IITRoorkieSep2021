
public class LeftRotator {

	public void leftRotation(int arr[],int mid,int size)
	{
		for(int i=0;i<mid;i++)
		{
			leftRotateByOne(arr,size);
		}
	
	}
	public void leftRotateByOne(int arr[],int size)
	{
		int temp;
		temp = arr[0];
		for(int i=0;i<size-1;i++)
		{
			arr[i] = arr[i+1];
			
		}
		arr[size-1] = temp;
	}
}
