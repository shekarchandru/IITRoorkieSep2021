import java.util.Scanner;

public class EntryPoint {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan1 = new Scanner(System.in);
		int size;
		System.out.println("Enter the size of the Array You wish to Generate...");
		size = scan1.nextInt();
		System.out.println("Enter the Elements of the Array...");
		int array[] = new int[size];
		for(int i=0;i<size;i++)
		{
			array[i] = scan1.nextInt();
		}
		System.out.println("The Array Generated is ...");
		for(int i=0;i<size;i++)
		{
			System.out.print(array[i]+" ");
		}
		System.out.println();
		MergeSorter mSorter = new MergeSorter();
		
		mSorter.sort(array, 0, array.length-1);
		System.out.println("The Sorted Array is ");
		for(int i=0;i<array.length;i++)
		{
			System.out.print(array[i]+" ");
		}
		int mid = (array.length)/2;
		LeftRotator lRotate = new LeftRotator();
		lRotate.leftRotation(array, mid, size);
		System.out.println();
		System.out.println("The Left Rotated ARray Elements are ");
		for(int i=0;i<array.length;i++)
		{
			System.out.print(array[i]+" ");
		}
		int target;
		System.out.println("Enter the Target Value you want to search ...");
		target = scan1.nextInt();
		int myIndex = BinarySearchSimplified.findIndex(array, target);
		if( myIndex != -1)
		{
			System.out.println("The Target element "+target+" is found at Index "+myIndex);
		}
		else
		{
			System.out.println("The Target Element is not found in the Given Array..");
		}

	}

}
